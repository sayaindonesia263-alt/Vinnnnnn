# PhotoCraft Android — proyek sumber

ZIP ini membungkus PhotoCraft Web build 0.7.0 dalam aplikasi Android WebView. **Ini belum APK siap instal.** APK debug dapat dibuat secara online melalui GitHub Actions, tanpa laptop, menggunakan browser HP.

## Cara membuat APK hanya dengan HP
1. Unduh ZIP proyek ini dan ekstrak menggunakan aplikasi pengelola ZIP di HP.
2. Buka https://github.com/ dan buat akun/masuk.
3. Buat repository baru bernama `PhotoCraft-Android`. Pilih **Public** (agar mudah mengikuti langkah ini) dan centang **Add a README file**.
4. Masuk ke repository. Tekan **Add file → Upload files**. Unggah isi folder `PhotoCraft-Android-Project` hasil ekstrak (termasuk folder tersembunyi `.github`; jika aplikasi ZIP menyembunyikannya, gunakan metode upload lewat browser/komputer lain atau tambahkan file workflow secara manual).
5. Tekan **Commit changes** dan pastikan file `.github/workflows/build-apk.yml` ada pada branch `main`.
6. Buka tab **Actions** → pilih **Build PhotoCraft Android APK** → **Run workflow** → **Run workflow**.
7. Tunggu hingga job selesai dengan tanda centang hijau. Buka hasil run tersebut, gulir ke **Artifacts**, lalu unduh `PhotoCraft-Android-APK`.
8. Ekstrak ZIP artifact yang diunduh. Di dalamnya ada `app-debug.apk`. Tekan file itu untuk memasang. Jika Android meminta izin, izinkan instalasi untuk aplikasi browser/pengelola file yang kamu gunakan.

## Catatan
- APK debug ini tidak ditandatangani untuk distribusi Play Store.
- PhotoCraft Web build belum diuji pada semua perangkat Android; beberapa fitur seperti impor/ekspor file, sentuhan, atau performa mungkin tidak sempurna.
- Gunakan hanya jika kamu mempercayai sumber proyek dan memahami bahwa pemasangan APK dari luar Play Store memiliki risiko.
